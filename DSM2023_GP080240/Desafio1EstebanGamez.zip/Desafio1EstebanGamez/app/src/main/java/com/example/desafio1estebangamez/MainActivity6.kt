package com.example.desafio1estebangamez

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.desafio1estebangamez.databinding.ActivityMain6Binding


class MainActivity6 : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityMain6Binding.inflate(layoutInflater)
        setContentView(binding.root)
        val bundle = intent.extras
        val x1 = bundle?.getString("X1")
        val x2 = bundle?.getString("X2")
        binding.lblX1.setText(x1)
        binding.lblX2.setText(x2)
        binding.btnLogOut.setOnClickListener{logOut()}
    }
    private  fun logOut() {
        val  sp = getSharedPreferences("my_prefs", Context.MODE_PRIVATE)
        with(sp.edit())
        {
            putString("active", "false")
            apply()
        }
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
}