package com.example.desafio1estebangamez

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.Spinner
import com.example.desafio1estebangamez.databinding.ActivityMain3Binding
import java.util.*

lateinit var Nombre: EditText
lateinit var CodigoEmpleado: EditText
lateinit var TotalVenta: EditText
lateinit var Mes: EditText

class MainActivity3 : AppCompatActivity() {


    var contador = 0
    var TotalComision = 0.0
    var NombreC = ""
    var CodigoEmpleadoC= ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityMain3Binding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnLogOut.setOnClickListener{logOut()}

        Nombre=findViewById(R.id.txtNombreCompleto);
        CodigoEmpleado=findViewById(R.id.txtCodEmpleado);
        TotalVenta=findViewById(R.id.txtTotalVentas);
        Mes=findViewById(R.id.txtMes);

        binding.btnEnviarOpcion1.setOnClickListener{reporte()}
        binding.btnAgregar.setOnClickListener{agregar()}
    }

    private fun agregar() {
        val venta: String = TotalVenta.text.toString()
        val name: String = Nombre.text.toString()
        val cod: String = CodigoEmpleado.text.toString()
        val mes: String = Mes.text.toString()

        var NumVenta = venta.toDouble()
        var comision = 0.0
        if(NumVenta<500){
            comision = 0.0
        }
        if(NumVenta>=500 && NumVenta<1000) {
            comision = (NumVenta*(0.05)).toDouble()
        }
        if(NumVenta>=1000 && NumVenta<2000) {
            comision = (NumVenta*(0.1)).toDouble()
        }
        if(NumVenta>=2000 && NumVenta<3000) {
            comision = (NumVenta*(0.15)).toDouble()
        }
        if(NumVenta>=3000 && NumVenta<4000) {
            comision = (NumVenta*(0.2)).toDouble()
        }
        if(NumVenta>=4000) {
            comision = (NumVenta*(0.3)).toDouble()
        }
        TotalComision = TotalComision  + comision

        val comisionF = comision.toString()
        val totalComisionf = TotalComision.toString()



    }

    private fun reporte() {
        val intent = Intent(this, MainActivity5::class.java)

        intent.putExtra("Nombre_Completo", Nombre.text.toString())
        intent.putExtra("Codigo_empleado", CodigoEmpleado.text.toString())
        intent.putExtra("Total_Comision", TotalComision.toString())
        intent.putExtra("Total_Venta", TotalVenta.text.toString())
        intent.putExtra("Mes", Mes.text.toString())
        startActivity(intent)
        finish()
    }

    private  fun logOut() {
        val  sp = getSharedPreferences("my_prefs", Context.MODE_PRIVATE)
        with(sp.edit())
        {
            putString("active", "false")
            apply()
        }
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
}