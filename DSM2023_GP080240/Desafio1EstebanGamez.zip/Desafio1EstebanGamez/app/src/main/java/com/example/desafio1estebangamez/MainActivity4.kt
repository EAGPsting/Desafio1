package com.example.desafio1estebangamez

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import com.example.desafio1estebangamez.databinding.ActivityMain4Binding
import kotlin.math.sqrt

lateinit var A: EditText
lateinit var B: EditText
lateinit var C: EditText
class MainActivity4 : AppCompatActivity() {
    var X1 =0.0
    var X2 =0.0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityMain4Binding.inflate(layoutInflater)
        setContentView(binding.root)
        A=findViewById(R.id.txtA);
        B=findViewById(R.id.txtB);
        C=findViewById(R.id.txtC);
        binding.btnCalcular.setOnClickListener{calcular()}
        binding.btnLogOut.setOnClickListener{logOut()}
    }

    private fun calcular(){
        val VA: String = A.text.toString()
        val VB: String = B.text.toString()
        val VC: String = C.text.toString()
        val a =VA.toDouble()
        val b =VB.toDouble()
        val c = VC.toDouble()
        var x1 = 0.0
        var x2 = 0.0
        var raiz =0.0
        val denominador = 2*a
        val discriminante = b*b - 4*a*c
        x1= -1*b/2*a
        if(discriminante>0)
        {
            raiz= sqrt(discriminante)
            x1 = -1*b+raiz/2*a
            x2 = -1*b-raiz/2*a
        }
        val intent = Intent(this, MainActivity6::class.java)
        X1=x1
        intent.putExtra( "X1", X1.toString())
        if(x2>0.0) {
            X2=x2
            intent.putExtra( "X2", X2.toString())
        }
        else
        {
            intent.putExtra( "X2", "NoExiste")
        }
        startActivity(intent)
        finish()
    }

    private  fun logOut() {
        val  sp = getSharedPreferences("my_prefs", Context.MODE_PRIVATE)
        with(sp.edit())
        {
            putString("active", "false")
            apply()
        }
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
}