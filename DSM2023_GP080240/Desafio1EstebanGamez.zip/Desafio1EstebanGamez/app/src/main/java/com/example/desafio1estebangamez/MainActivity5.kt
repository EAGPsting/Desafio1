package com.example.desafio1estebangamez

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity
import com.example.desafio1estebangamez.databinding.ActivityMain5Binding


class MainActivity5 : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityMain5Binding.inflate(layoutInflater)
        setContentView(binding.root)
        val bundle = intent.extras
        val name = bundle?.getString("Nombre_Completo")
        val cod = bundle?.getString("Codigo_empleado")
        val totalComision = bundle?.getString("Total_Comision")
        val totalVenta = bundle?.getString("Total_Venta")
        val Mes = bundle?.getString("Mes")

        binding.lblNombre.setText(name)
        binding.lblCodigo.setText(cod)
        binding.lblVenta.setText(totalVenta)
        binding.lblMes.setText(Mes)
        binding.lblTotalComision.setText(totalComision)
        binding.btnLogOut.setOnClickListener{logOut()}
        binding.btnNuevaVenta.setOnClickListener{atras()}
    }

    private fun atras() {
        startActivity(Intent(this, MainActivity3::class.java))
        finish()
    }

    private  fun logOut() {
        val  sp = getSharedPreferences("my_prefs", Context.MODE_PRIVATE)
        with(sp.edit())
        {
            putString("active", "false")
            apply()
        }
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
}