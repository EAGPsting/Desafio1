package com.example.desafio1estebangamez

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.Toast
import com.example.desafio1estebangamez.databinding.ActivityMainBinding


class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val sp = getSharedPreferences("my_prefs", Context.MODE_PRIVATE)
        checkLogIn(sp)
        binding.btnLogIn.setOnClickListener{rememberUser(sp)}
    }


    private fun rememberUser(sp: SharedPreferences)
    {
        val email = binding.textFieldEmail.editText?.text.toString()

        val password =binding.textFieldPassword.editText?.text.toString()

            if (email.isNotEmpty() && password.isNotEmpty()) {
                val checkBox = binding.checkBox

                if (checkBox.isChecked){
                    with(sp.edit()){
                        putString("email", email)
                        putString("password", password)
                        putString("active", "true")
                        putString("remember", "true")
                        apply()
                    }
                }else{
                    with(sp.edit()){
                        putString("active", "true")
                        putString("remember", "false")
                        apply()
                    }
                }
                startActivity(Intent(this, MainActivity2::class.java))
                finish()
            }else{
                Toast.makeText(this, "Failed...try again", Toast.LENGTH_SHORT).show()
            }

    }

    private fun checkLogIn(sp : SharedPreferences){
        if(sp.getString("active", "") == "true"){
            startActivity(Intent(this, MainActivity2::class.java))
            finish()
        }else {
            if(sp.getString("remember","") == "true"){
                binding.textFieldEmail.editText?.setText(sp.getString("email", ""))
                binding.textFieldPassword.editText?.setText(sp.getString("password", ""))
            }
        }
    }
}