package com.example.desafio1estebangamez

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.desafio1estebangamez.databinding.ActivityMain2Binding


class MainActivity2 : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityMain2Binding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnLogOut.setOnClickListener{logOut()}
        binding.btnOpcion1.setOnClickListener{opcion1()}
        binding.btnOpcion2.setOnClickListener{opcion2()}
    }

    private fun opcion2() {
        startActivity(Intent(this, MainActivity4::class.java))
        finish()
    }

    private fun opcion1() {
        startActivity(Intent(this, MainActivity3::class.java))
        finish()
    }

    private  fun logOut() {
        val  sp = getSharedPreferences("my_prefs", Context.MODE_PRIVATE)
        with(sp.edit())
        {
            putString("active", "false")
            apply()
        }
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
}